DICOM Test data
===============

Generated data
----------------
* dwv-test-simple: simple data with basic tags
* dwv-test-sequence: trying to list all possible sequences...

External sources
-----------------
* Babymri: http://www.babymri.org/
* Dicompyler: http://www.dicompyler.com/
* Gdcm: :pserver:xxx@cvs.creatis.insa-lyon.fr:2402/cvs/public
* Leadtools: (from Creatis) http://www.creatis.insa-lyon.fr/~jpr/PUBLIC/gdcm/gdcmSampleData/ColorDataSetLeadTool/
* Nema WG04 (jpeg): ftp://medical.nema.org/MEDICAL/Dicom/DataSets/WG04/
* Osirix: http://www.osirix-viewer.com/datasets/
