Third Party: rii-mango
======================

JPEGLosslessDecoderJS
---------------------
* Web: https://github.com/rii-mango/JPEGLosslessDecoderJS
* Version: [1.2.1](https://github.com/rii-mango/JPEGLosslessDecoderJS/releases/tag/1.2.1)
* Date: 29/09/2015
* Download: see release
* License: LGPL (see https://github.com/rii-mango/JPEGLosslessDecoderJS/blob/master/LICENSE)
* Description: JPEG Lossless decoder.
* Purpose for dwv: Decode JPEG embeded in DICOM.
