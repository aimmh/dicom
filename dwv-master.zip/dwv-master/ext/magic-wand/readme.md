Third Party: magic-wand
=======================

* Web: https://github.com/Tamersoul/magic-wand-js
* Version: git commit: 39d50ec17bfc060f2d360537a26a9420dd8970b6
* Date: 20/05/2016
* Download: https://github.com/Tamersoul/magic-wand-js/tree/master/js
* License: MIT (see https://github.com/Tamersoul/magic-wand-js/blob/master/LICENSE.txt)
* Description: Magic wand tool (fuzzy selection) by color for Javascript.
* Purpose for dwv: dependency of the floodfill tool.
