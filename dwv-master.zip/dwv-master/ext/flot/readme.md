Third Party: flot
=================

* Web: http://www.flotcharts.org/
* Version: [0.8.3](http://www.flotcharts.org/blog/2014/04/21/flot-083-released/)
* Date: 21/04/2014
* Download: [flot-0.8.3.zip](http://www.flotcharts.org/downloads/flot-0.8.3.zip)
* License: [MIT](http://www.opensource.org/licenses/mit-license.php)
  (see [license.txt](/ivmartel/dwv/blob/master/ext/flot/license.txt))
* Description: Flot is a pure Javascript plotting library for jQuery.
  It produces graphical plots of arbitrary datasets on-the-fly
  client-side.
* Purpose for dwv: Used for the plotting of the image data histogram.
