Third Party: jquery-ui
======================

* Web: http://jqueryui.com
* Version: 1.12.0, no official announcement
* Date: 28/08/2015
* Download: [custom](http://jqueryui.com/download/) (default options with ui-darkness theme)
* License: MIT (see http://jquery.org/license)
* CDN (js): [jquery-ui.min.js](http://code.jquery.com/ui/1.12.0/jquery-ui.min.js)
* CDN (css): [jquery-ui.min.css](http://code.jquery.com/ui/1.12.0/themes/ui-darkness/jquery-ui.min.css)
* Description: jQuery UI provides abstractions for low-level interaction and animation,
  advanced effects and high-level, themeable widgets, built on top of the jQuery
  JavaScript Library, that you can use to build highly interactive web applications.
* Purpose for dwv: DWV user interface.
