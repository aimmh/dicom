Third Party: qunit
===================

* Web: http://qunitjs.com/
* Version: [2.3.0](https://github.com/jquery/qunit/releases/tag/2.3.0)
* Date: 29/03/2017
* Download: see CDN
* License: MIT (see http://jquery.org/license)
* CDN (js): [qunit-2.3.0.js](http://code.jquery.com/qunit/qunit-2.3.0.js)
* CDN (css): [qunit-2.3.0.css](http://code.jquery.com/qunit/qunit-2.3.0.css)
* Description: QUnit is a powerful, easy-to-use JavaScript unit test suite.
* Purpose for dwv: DWV unit test suite.
