Third Party: konvajs
======================

* Web: https://konvajs.github.io/
* Version: 1.6.0
* Date: 20/04/2017
* Download: https://cdn.rawgit.com/konvajs/konva/1.6.0/konva.min.js
* License: MIT or GPL Version 2 (see https://github.com/konvajs/konva/blob/master/src/Global.js)
* Description: KonvaJS is an HTML5 Canvas JavaScript framework that extends the 2d context by enabling canvas interactivity for desktop and mobile applications..
* Purpose for dwv: Used for handling drawings.
