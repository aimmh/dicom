Third Party: jquery-mobile
==========================

* Web: http://jquerymobile.com/
* Version: [1.4.5](http://blog.jquerymobile.com/2014/10/31/jquery-mobile-1-4-5-released/)
* Date: 31/10/2014
* Download: see CDN
* License: MIT (see http://jquery.org/license)
* CDN (js): [jquery.mobile-1.4.5.min.js](http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js)
* CDN (css): [jquery.mobile-1.4.5.min.css](http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css)
* Description: A unified, HTML5-based user interface system for all popular mobile
  device platforms, built on the rock-solid jQuery and jQuery UI foundation..
* Purpose for dwv: DWV mobile user interface.
