Third Party: jquery
===================

* Web: http://jquery.com
* Version: [2.1.4](http://blog.jquery.com/2015/04/28/jquery-1-11-3-and-2-1-4-released-ios-fail-safe-edition/)
* Date: 28/04/2015
* Download: from CDN
* License: MIT (see http://jquery.org/license)
* CDN: [jquery-2.1.4.min.js](http://code.jquery.com/jquery-2.1.4.min.js)
* Description: jQuery is a fast and concise JavaScript Library that simplifies HTML
  document traversing, event handling, animating, and Ajax interactions
  for rapid web development.
* Purpose for dwv: Core of jqueryui and jquery.mobile user interface.
