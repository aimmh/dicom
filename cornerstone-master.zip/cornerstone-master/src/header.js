if(typeof cornerstone === 'undefined'){
    cornerstone = {
        internal : {},
        rendering: {},
        colors: {}
    };
}
