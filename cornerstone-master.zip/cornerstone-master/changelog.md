# Version 0.10.7

- Revert fix for #101 since it's reducing performance